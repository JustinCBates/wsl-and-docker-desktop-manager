"""Uninstall WSL package."""
