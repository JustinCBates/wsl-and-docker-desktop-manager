"""Uninstall docker package."""
