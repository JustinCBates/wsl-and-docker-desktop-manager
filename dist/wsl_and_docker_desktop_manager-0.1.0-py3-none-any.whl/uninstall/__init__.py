"""Uninstall package."""
